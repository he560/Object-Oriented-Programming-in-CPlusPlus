#include "Warrior.hpp"

//warrior constructor takes the name and strength and sets the base
//name and strength
Warrior::Warrior(const std::string& name, int strength) : Protector(name, strength) {}
//the get strength uses the bases get strength.
int Warrior::getStrength() const {
    return Protector::getStrength();
}

